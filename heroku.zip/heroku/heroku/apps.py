from django.apps import AppConfig


class HerokuConfig(AppConfig):
    name = 'heroku'
